(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/query-client.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QueryProvider",
    ()=>QueryProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function QueryProvider({ children }) {
    _s();
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "QueryProvider.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
                defaultOptions: {
                    queries: {
                        // Data considered fresh for 1 minute
                        staleTime: 60 * 1000,
                        // Cache data for 5 minutes
                        gcTime: 5 * 60 * 1000,
                        // Retry failed requests 3 times
                        retry: 3,
                        // Refetch on window focus
                        refetchOnWindowFocus: true
                    },
                    mutations: {
                        // Retry mutations once
                        retry: 1
                    }
                }
            })
    }["QueryProvider.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: children
    }, void 0, false, {
        fileName: "[project]/lib/query-client.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_s(QueryProvider, "pVq+bjmTAibKubIP+CgPPsAgH+U=");
_c = QueryProvider;
;
var _c;
__turbopack_context__.k.register(_c, "QueryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/stores/ui-store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useUIStore",
    ()=>useUIStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
;
;
const useUIStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((set)=>({
        // Theme - default to system
        theme: "system",
        setTheme: (theme)=>set({
                theme
            }),
        // Sidebar
        sidebarOpen: false,
        setSidebarOpen: (open)=>set({
                sidebarOpen: open
            }),
        toggleSidebar: ()=>set((state)=>({
                    sidebarOpen: !state.sidebarOpen
                })),
        // Cart sidebar
        cartSidebarOpen: false,
        setCartSidebarOpen: (open)=>set({
                cartSidebarOpen: open
            }),
        // Mobile menu
        mobileMenuOpen: false,
        setMobileMenuOpen: (open)=>set({
                mobileMenuOpen: open
            }),
        // Search
        searchOpen: false,
        setSearchOpen: (open)=>set({
                searchOpen: open
            }),
        searchQuery: "",
        setSearchQuery: (query)=>set({
                searchQuery: query
            })
    }), {
    name: "dailycup-ui",
    storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>localStorage),
    partialize: (state)=>({
            theme: state.theme
        })
}));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/toast-provider.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToastProvider",
    ()=>ToastProvider,
    "showToast",
    ()=>showToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$ui$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/stores/ui-store.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ToastProvider() {
    _s();
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$ui$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUIStore"])({
        "ToastProvider.useUIStore[theme]": (state)=>state.theme
    }["ToastProvider.useUIStore[theme]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toaster"], {
        position: "top-right",
        expand: false,
        richColors: true,
        closeButton: true,
        theme: theme === "system" ? undefined : theme,
        toastOptions: {
            duration: 4000,
            style: {
                background: "var(--toast-bg, white)",
                color: "var(--toast-color, #333)",
                border: "1px solid var(--toast-border, #e5e7eb)"
            }
        }
    }, void 0, false, {
        fileName: "[project]/components/ui/toast-provider.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_s(ToastProvider, "7m865X9v0jW+8EavH9E3SxsZJog=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$ui$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUIStore"]
    ];
});
_c = ToastProvider;
const showToast = {
    success: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(message),
    error: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(message),
    info: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].info(message),
    warning: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].warning(message),
    loading: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].loading(message),
    promise: (promise, messages)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].promise(promise, messages)
};
;
var _c;
__turbopack_context__.k.register(_c, "ToastProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/error-boundary.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ErrorBoundary",
    ()=>ErrorBoundary,
    "withErrorBoundary",
    ()=>withErrorBoundary
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
class ErrorBoundary extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"] {
    state = {
        hasError: false,
        error: null
    };
    static getDerivedStateFromError(error) {
        return {
            hasError: true,
            error
        };
    }
    componentDidCatch(error, errorInfo) {
        console.error("ErrorBoundary caught an error:", error, errorInfo);
        // Call custom error handler if provided
        this.props.onError?.(error, errorInfo);
        // Show toast notification
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Something went wrong", {
            description: "We're sorry for the inconvenience. Please try refreshing the page."
        });
    // TODO: Send to error tracking service (Sentry)
    // if (featureFlags.sentryEnabled) {
    //   Sentry.captureException(error, { extra: errorInfo });
    // }
    }
    handleRetry = ()=>{
        this.setState({
            hasError: false,
            error: null
        });
    };
    render() {
        if (this.state.hasError) {
            if (this.props.fallback) {
                return this.props.fallback;
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-h-[400px] flex flex-col items-center justify-center p-8 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-8 h-8 text-red-600",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/error-boundary.tsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ui/error-boundary.tsx",
                            lineNumber: 57,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ui/error-boundary.tsx",
                        lineNumber: 56,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold text-gray-900 mb-2",
                        children: "Oops! Something went wrong"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/error-boundary.tsx",
                        lineNumber: 72,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 mb-6 max-w-md",
                        children: "We encountered an unexpected error. Please try again or contact support if the problem persists."
                    }, void 0, false, {
                        fileName: "[project]/components/ui/error-boundary.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: this.handleRetry,
                                className: "px-4 py-2 bg-[#a97456] text-white rounded-lg hover:bg-[#8a5a3d] transition-colors",
                                children: "Try Again"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/error-boundary.tsx",
                                lineNumber: 81,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>window.location.reload(),
                                className: "px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors",
                                children: "Refresh Page"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/error-boundary.tsx",
                                lineNumber: 88,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/error-boundary.tsx",
                        lineNumber: 80,
                        columnNumber: 11
                    }, this),
                    ("TURBOPACK compile-time value", "development") === "development" && this.state.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "mt-6 text-left w-full max-w-2xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                className: "text-sm text-gray-500 cursor-pointer hover:text-gray-700",
                                children: "Error Details (Development Only)"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/error-boundary.tsx",
                                lineNumber: 98,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                className: "mt-2 p-4 bg-gray-100 rounded-lg text-xs overflow-auto",
                                children: [
                                    this.state.error.toString(),
                                    "\n\n",
                                    this.state.error.stack
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ui/error-boundary.tsx",
                                lineNumber: 101,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/error-boundary.tsx",
                        lineNumber: 97,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/error-boundary.tsx",
                lineNumber: 55,
                columnNumber: 9
            }, this);
        }
        return this.props.children;
    }
}
function withErrorBoundary(WrappedComponent, fallback) {
    return function WithErrorBoundaryWrapper(props) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ErrorBoundary, {
            fallback: fallback,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WrappedComponent, {
                ...props
            }, void 0, false, {
                fileName: "[project]/components/ui/error-boundary.tsx",
                lineNumber: 124,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/ui/error-boundary.tsx",
            lineNumber: 123,
            columnNumber: 7
        }, this);
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/contexts/CartContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CartProvider",
    ()=>CartProvider,
    "useCart",
    ()=>useCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const initialState = {
    items: [],
    total: 0,
    itemCount: 0
};
function cartReducer(state, action) {
    switch(action.type){
        case 'ADD_ITEM':
            {
                const { product, selectedVariants = {}, quantity = 1 } = action.payload;
                // Build a deterministic itemId from product + selected variant values
                const variantKey = Object.keys(selectedVariants).sort().map((k)=>`${k}:${selectedVariants[k]}`).join('|');
                const itemId = `${product.id}-${variantKey}`;
                const existingItem = state.items.find((item)=>item.id === itemId);
                let newItems;
                if (existingItem) {
                    newItems = state.items.map((item)=>item.id === itemId ? {
                            ...item,
                            quantity: item.quantity + quantity,
                            totalPrice: item.totalPrice / item.quantity * (item.quantity + quantity)
                        } : item);
                } else {
                    // Calculate price by applying variant adjustments dynamically
                    let price = product.price || product.base_price || 0;
                    Object.entries(selectedVariants).forEach(([variantType, value])=>{
                        const adj = product.variants?.[variantType]?.find((v)=>v.value === value)?.price_adjustment || 0;
                        price += adj;
                    });
                    const newItem = {
                        id: itemId,
                        product,
                        quantity,
                        size: selectedVariants['size'] ?? undefined,
                        temperature: selectedVariants['temperature'] ?? undefined,
                        selectedVariants,
                        totalPrice: price * quantity
                    };
                    newItems = [
                        ...state.items,
                        newItem
                    ];
                }
                const total = newItems.reduce((sum, item)=>sum + item.totalPrice, 0);
                const itemCount = newItems.reduce((sum, item)=>sum + item.quantity, 0);
                return {
                    items: newItems,
                    total,
                    itemCount
                };
            }
        case 'REMOVE_ITEM':
            {
                const newItems = state.items.filter((item)=>item.id !== action.payload.id);
                const total = newItems.reduce((sum, item)=>sum + item.totalPrice, 0);
                const itemCount = newItems.reduce((sum, item)=>sum + item.quantity, 0);
                return {
                    items: newItems,
                    total,
                    itemCount
                };
            }
        case 'UPDATE_QUANTITY':
            {
                const { id, quantity } = action.payload;
                if (quantity <= 0) {
                    return cartReducer(state, {
                        type: 'REMOVE_ITEM',
                        payload: {
                            id
                        }
                    });
                }
                const newItems = state.items.map((item)=>{
                    if (item.id === id) {
                        const newQuantity = quantity;
                        const newTotalPrice = item.totalPrice / item.quantity * newQuantity;
                        return {
                            ...item,
                            quantity: newQuantity,
                            totalPrice: newTotalPrice
                        };
                    }
                    return item;
                });
                const total = newItems.reduce((sum, item)=>sum + item.totalPrice, 0);
                const itemCount = newItems.reduce((sum, item)=>sum + item.quantity, 0);
                return {
                    items: newItems,
                    total,
                    itemCount
                };
            }
        case 'CLEAR_CART':
            return initialState;
        case 'LOAD_CART':
            const loadedItems = action.payload;
            const total = loadedItems.reduce((sum, item)=>sum + item.totalPrice, 0);
            const itemCount = loadedItems.reduce((sum, item)=>sum + item.quantity, 0);
            return {
                items: loadedItems,
                total,
                itemCount
            };
        default:
            return state;
    }
}
const CartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function CartProvider({ children }) {
    _s();
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(cartReducer, initialState);
    // Load cart from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            const savedCart = localStorage.getItem('dailycup-cart');
            if (savedCart) {
                try {
                    const cartItems = JSON.parse(savedCart);
                    dispatch({
                        type: 'LOAD_CART',
                        payload: cartItems
                    });
                } catch (error) {
                    console.error('Error loading cart from localStorage:', error);
                }
            }
        }
    }["CartProvider.useEffect"], []);
    // Save cart to localStorage whenever it changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CartProvider.useEffect": ()=>{
            localStorage.setItem('dailycup-cart', JSON.stringify(state.items));
        }
    }["CartProvider.useEffect"], [
        state.items
    ]);
    const addItem = (product, selectedVariants = {}, quantity = 1)=>{
        dispatch({
            type: 'ADD_ITEM',
            payload: {
                product,
                selectedVariants,
                quantity
            }
        });
    };
    const removeItem = (id)=>{
        dispatch({
            type: 'REMOVE_ITEM',
            payload: {
                id
            }
        });
    };
    const updateQuantity = (id, quantity)=>{
        dispatch({
            type: 'UPDATE_QUANTITY',
            payload: {
                id,
                quantity
            }
        });
    };
    const clearCart = ()=>{
        dispatch({
            type: 'CLEAR_CART'
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CartContext.Provider, {
        value: {
            state,
            addItem,
            removeItem,
            updateQuantity,
            clearCart
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/CartContext.tsx",
        lineNumber: 157,
        columnNumber: 5
    }, this);
}
_s(CartProvider, "GUSXxL/WUElrtHc/X73NyHNRMdw=");
_c = CartProvider;
function useCart() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CartContext);
    if (context === undefined) {
        throw new Error('useCart must be used within a CartProvider');
    }
    return context;
}
_s1(useCart, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "CartProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/MockNotice.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MockNotice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function MockNotice() {
    _s();
    const [show, setShow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [endpoint, setEndpoint] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MockNotice.useEffect": ()=>{
            const handler = {
                "MockNotice.useEffect.handler": (e)=>{
                    const detail = e.detail;
                    setEndpoint(detail?.endpoint || null);
                    setShow(true);
                }
            }["MockNotice.useEffect.handler"];
            window.addEventListener('api:mock', handler);
            return ({
                "MockNotice.useEffect": ()=>window.removeEventListener('api:mock', handler)
            })["MockNotice.useEffect"];
        }
    }["MockNotice.useEffect"], []);
    if (!show) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed top-6 right-6 z-50 max-w-xs w-full bg-yellow-50 border border-yellow-300 text-yellow-900 p-3 rounded shadow",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start gap-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            className: "block",
                            children: "Using mock data"
                        }, void 0, false, {
                            fileName: "[project]/components/MockNotice.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs mt-1",
                            children: [
                                "Some API calls failed, app is using local mock data",
                                endpoint ? ` for ${endpoint}` : '',
                                "."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/MockNotice.tsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/MockNotice.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setShow(false),
                        className: "text-sm text-yellow-800 hover:text-yellow-900 px-2 py-1",
                        "aria-label": "Dismiss mock notice",
                        children: "✕"
                    }, void 0, false, {
                        fileName: "[project]/components/MockNotice.tsx",
                        lineNumber: 30,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/MockNotice.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/MockNotice.tsx",
            lineNumber: 24,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/MockNotice.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
_s(MockNotice, "psMdZZtOGP+gvpUR3cRPFClWWsI=");
_c = MockNotice;
var _c;
__turbopack_context__.k.register(_c, "MockNotice");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Toast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Toast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function Toast() {
    _s();
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Toast.useEffect": ()=>{
            let idCounter = 1;
            const handler = {
                "Toast.useEffect.handler": (e)=>{
                    const detail = e.detail;
                    const text = detail?.message || (detail?.endpoint ? `Using mock data for ${detail.endpoint}` : 'Using mock data');
                    const id = idCounter++;
                    setMessages({
                        "Toast.useEffect.handler": (prev)=>[
                                ...prev,
                                {
                                    id,
                                    text
                                }
                            ]
                    }["Toast.useEffect.handler"]);
                    // Auto remove after 5s
                    setTimeout({
                        "Toast.useEffect.handler": ()=>{
                            setMessages({
                                "Toast.useEffect.handler": (prev)=>prev.filter({
                                        "Toast.useEffect.handler": (m)=>m.id !== id
                                    }["Toast.useEffect.handler"])
                            }["Toast.useEffect.handler"]);
                        }
                    }["Toast.useEffect.handler"], 5000);
                }
            }["Toast.useEffect.handler"];
            window.addEventListener('api:mock', handler);
            return ({
                "Toast.useEffect": ()=>window.removeEventListener('api:mock', handler)
            })["Toast.useEffect"];
        }
    }["Toast.useEffect"], []);
    if (messages.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed bottom-6 right-6 z-50 flex flex-col gap-2",
        children: messages.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-black/85 text-white px-4 py-2 rounded shadow-lg max-w-xs",
                children: m.text
            }, m.id, false, {
                fileName: "[project]/components/Toast.tsx",
                lineNumber: 30,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/components/Toast.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_s(Toast, "RyA59LRbn9goj/9N7rELX+NWNVI=");
_c = Toast;
var _c;
__turbopack_context__.k.register(_c, "Toast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ClientUI.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ClientUI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$MockNotice$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/MockNotice.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Toast.tsx [app-client] (ecmascript)");
'use client';
;
;
;
function ClientUI() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$MockNotice$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/ClientUI.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/ClientUI.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = ClientUI;
var _c;
__turbopack_context__.k.register(_c, "ClientUI");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/stores/notification-store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchNotifications",
    ()=>fetchNotifications,
    "useNotificationStore",
    ()=>useNotificationStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost/DailyCup/webapp/backend/api") || 'http://localhost/DailyCup/webapp/backend/api';
async function fetchWithAuth(url, options = {}) {
    const token = localStorage.getItem('dailycup-auth');
    let authToken = '';
    if (token) {
        try {
            const parsed = JSON.parse(token);
            authToken = parsed.state?.token || '';
        } catch  {}
    }
    return fetch(url, {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            ...authToken ? {
                'Authorization': `Bearer ${authToken}`
            } : {},
            ...options.headers
        },
        credentials: 'include'
    });
}
const useNotificationStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        notifications: [],
        unreadCount: 0,
        isLoading: false,
        hasMore: true,
        offset: 0,
        pollingInterval: null,
        isConnected: false,
        setNotifications: (notifications)=>{
            // Deduplicate by ID
            const uniqueNotifications = notifications.filter((notif, index, self)=>index === self.findIndex((t)=>t.id === notif.id));
            set({
                notifications: uniqueNotifications
            });
        },
        addNotification: (notification)=>{
            set((state)=>{
                // Check if notification already exists
                const exists = state.notifications.some((n)=>n.id === notification.id);
                if (exists) return state;
                return {
                    notifications: [
                        notification,
                        ...state.notifications
                    ],
                    unreadCount: state.unreadCount + (notification.is_read ? 0 : 1)
                };
            });
        },
        appendNotifications: (notifications, hasMore)=>{
            set((state)=>{
                // Get existing IDs
                const existingIds = new Set(state.notifications.map((n)=>n.id));
                // Filter out duplicates
                const newNotifications = notifications.filter((n)=>!existingIds.has(n.id));
                return {
                    notifications: [
                        ...state.notifications,
                        ...newNotifications
                    ],
                    hasMore
                };
            });
        },
        setUnreadCount: (count)=>{
            set({
                unreadCount: count
            });
        },
        markAsRead: (id)=>{
            set((state)=>({
                    notifications: state.notifications.map((n)=>n.id === id ? {
                            ...n,
                            is_read: true,
                            read_at: new Date().toISOString()
                        } : n),
                    unreadCount: Math.max(0, state.unreadCount - 1)
                }));
            // Call API
            fetchWithAuth(`${API_BASE_URL}/notifications/read.php`, {
                method: 'POST',
                body: JSON.stringify({
                    id
                })
            }).catch(console.error);
        },
        markAllAsRead: ()=>{
            set((state)=>({
                    notifications: state.notifications.map((n)=>({
                            ...n,
                            is_read: true,
                            read_at: n.read_at || new Date().toISOString()
                        })),
                    unreadCount: 0
                }));
            // Call API
            fetchWithAuth(`${API_BASE_URL}/notifications/read.php`, {
                method: 'POST',
                body: JSON.stringify({
                    all: true
                })
            }).catch(console.error);
        },
        removeNotification: (id)=>{
            const notification = get().notifications.find((n)=>n.id === id);
            set((state)=>({
                    notifications: state.notifications.filter((n)=>n.id !== id),
                    unreadCount: notification && !notification.is_read ? Math.max(0, state.unreadCount - 1) : state.unreadCount
                }));
            // Call API
            fetchWithAuth(`${API_BASE_URL}/notifications/delete.php?id=${id}`, {
                method: 'DELETE'
            }).catch(console.error);
        },
        setLoading: (loading)=>{
            set({
                isLoading: loading
            });
        },
        resetPagination: ()=>{
            set({
                offset: 0,
                hasMore: true,
                notifications: []
            });
        },
        incrementOffset: (amount)=>{
            set((state)=>({
                    offset: state.offset + amount
                }));
        },
        setConnected: (connected)=>{
            set({
                isConnected: connected
            });
        },
        startPolling: ()=>{
            const { pollingInterval } = get();
            if (pollingInterval) return; // Already polling
            // Fetch immediately
            fetchUnreadCount();
            // Then poll every 30 seconds
            const interval = window.setInterval(fetchUnreadCount, 30000);
            set({
                pollingInterval: interval
            });
            async function fetchUnreadCount() {
                try {
                    const res = await fetchWithAuth(`${API_BASE_URL}/notifications/count.php`);
                    if (res.ok) {
                        const data = await res.json();
                        set({
                            unreadCount: data.count || 0
                        });
                    }
                } catch (error) {
                    console.error('Failed to fetch notification count:', error);
                }
            }
        },
        stopPolling: ()=>{
            const { pollingInterval } = get();
            if (pollingInterval) {
                clearInterval(pollingInterval);
                set({
                    pollingInterval: null
                });
            }
        }
    }));
async function fetchNotifications(limit = 20, offset = 0, unreadOnly = false) {
    const params = new URLSearchParams({
        limit: String(limit),
        offset: String(offset),
        ...unreadOnly ? {
            unread: '1'
        } : {}
    });
    try {
        const res = await fetchWithAuth(`${API_BASE_URL}/notifications/get.php?${params}`);
        if (res.status === 401) {
            // Unauthorized: user not logged in or token expired
            return {
                success: false,
                unauthorized: true
            };
        }
        if (!res.ok) throw new Error(`Failed to fetch notifications: ${res.status}`);
        return await res.json();
    } catch (error) {
        console.error('fetchNotifications error:', error);
        return null;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/notificationClient.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NotificationClient",
    ()=>NotificationClient,
    "disconnectNotificationClient",
    ()=>disconnectNotificationClient,
    "getNotificationClient",
    ()=>getNotificationClient,
    "requestNotificationPermission",
    ()=>requestNotificationPermission,
    "showBrowserNotification",
    ()=>showBrowserNotification
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// Real-time notification client using Server-Sent Events (SSE)
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/stores/notification-store.ts [app-client] (ecmascript)");
;
class NotificationClient {
    eventSource = null;
    reconnectAttempts = 0;
    maxReconnectAttempts = 5;
    reconnectDelay = 1000;
    userId = null;
    isConnecting = false;
    constructor(userId){
        this.userId = userId || null;
    }
    connect(token) {
        if (this.isConnecting || this.eventSource) {
            console.log('[SSE] Already connected or connecting');
            return;
        }
        this.isConnecting = true;
        const apiUrl = ("TURBOPACK compile-time value", "http://localhost/DailyCup/webapp/backend/api") || 'http://localhost/DailyCup/webapp/backend/api';
        // Add ngrok bypass as query param since EventSource doesn't support custom headers
        const url = `${apiUrl}/notifications/stream.php?token=${encodeURIComponent(token)}&ngrok-skip-browser-warning=69420`;
        console.log('[SSE] Connecting to:', url);
        try {
            this.eventSource = new EventSource(url);
            this.eventSource.onopen = ()=>{
                console.log('[SSE] Connection established');
                this.reconnectAttempts = 0;
                this.isConnecting = false;
                __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().setConnected(true);
            };
            this.eventSource.onmessage = (event)=>{
                try {
                    const data = JSON.parse(event.data);
                    console.log('[SSE] Message received:', data);
                    if (data.type === 'ping') {
                        // Keep-alive ping, ignore
                        return;
                    }
                    if (data.type === 'notification') {
                        const notification = data.notification;
                        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().addNotification({
                            id: notification.id,
                            type: notification.type || 'info',
                            title: notification.title,
                            message: notification.message,
                            data: notification.data || {},
                            icon: notification.icon || '',
                            action_url: notification.action_url,
                            is_read: notification.is_read || false,
                            read_at: notification.read_at || null,
                            created_at: notification.created_at || new Date().toISOString()
                        });
                    }
                    if (data.type === 'unread_count') {
                        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().setUnreadCount(data.count);
                    }
                } catch (error) {
                    console.error('[SSE] Error parsing message:', error);
                }
            };
            this.eventSource.onerror = (error)=>{
                console.error('[SSE] Connection error:', error);
                this.isConnecting = false;
                __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().setConnected(false);
                if (this.eventSource) {
                    this.eventSource.close();
                    this.eventSource = null;
                }
                this.handleReconnect(token);
            };
            // Listen for specific event types
            this.eventSource.addEventListener('order_update', (event)=>{
                try {
                    const data = JSON.parse(event.data);
                    console.log('[SSE] Order update:', data);
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().addNotification({
                        id: Date.now(),
                        type: 'order',
                        title: 'Order Update',
                        message: data.message || 'Your order has been updated',
                        data: {
                            orderId: data.order_id,
                            status: data.status
                        },
                        icon: '',
                        action_url: `/orders/${data.order_id}`,
                        is_read: false,
                        read_at: null,
                        created_at: new Date().toISOString()
                    });
                } catch (error) {
                    console.error('[SSE] Error handling order update:', error);
                }
            });
            this.eventSource.addEventListener('payment_update', (event)=>{
                try {
                    const data = JSON.parse(event.data);
                    console.log('[SSE] Payment update:', data);
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().addNotification({
                        id: Date.now() + 1,
                        type: 'payment',
                        title: 'Payment Update',
                        message: data.message || 'Payment status updated',
                        data: {
                            orderId: data.order_id,
                            amount: data.amount
                        },
                        icon: '',
                        action_url: `/orders/${data.order_id}`,
                        is_read: false,
                        read_at: null,
                        created_at: new Date().toISOString()
                    });
                } catch (error) {
                    console.error('[SSE] Error handling payment update:', error);
                }
            });
            this.eventSource.addEventListener('promo', (event)=>{
                try {
                    const data = JSON.parse(event.data);
                    console.log('[SSE] Promo notification:', data);
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().addNotification({
                        id: Date.now() + 2,
                        type: 'promo',
                        title: data.title || 'Special Offer',
                        message: data.message,
                        data: {},
                        icon: data.image || '',
                        action_url: data.url,
                        is_read: false,
                        read_at: null,
                        created_at: new Date().toISOString()
                    });
                } catch (error) {
                    console.error('[SSE] Error handling promo:', error);
                }
            });
        } catch (error) {
            console.error('[SSE] Connection failed:', error);
            this.isConnecting = false;
            this.handleReconnect(token);
        }
    }
    handleReconnect(token) {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.log('[SSE] Max reconnection attempts reached');
            return;
        }
        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1); // Exponential backoff
        console.log(`[SSE] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        setTimeout(()=>{
            this.connect(token);
        }, delay);
    }
    disconnect() {
        console.log('[SSE] Disconnecting');
        if (this.eventSource) {
            this.eventSource.close();
            this.eventSource = null;
        }
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$notification$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotificationStore"].getState().setConnected(false);
    }
    isConnected() {
        return this.eventSource !== null && this.eventSource.readyState === EventSource.OPEN;
    }
}
// Singleton instance
let notificationClient = null;
function getNotificationClient(userId) {
    if (!notificationClient) {
        notificationClient = new NotificationClient(userId);
    }
    return notificationClient;
}
function disconnectNotificationClient() {
    if (notificationClient) {
        notificationClient.disconnect();
        notificationClient = null;
    }
}
async function requestNotificationPermission() {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !('Notification' in window)) {
        return 'denied';
    }
    if (Notification.permission === 'granted') {
        return 'granted';
    }
    if (Notification.permission !== 'denied') {
        const permission = await Notification.requestPermission();
        return permission;
    }
    return Notification.permission;
}
function showBrowserNotification(title, options) {
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !('Notification' in window)) {
        return;
    }
    if (Notification.permission === 'granted') {
        new Notification(title, {
            icon: '/assets/image/cup.png',
            badge: '/assets/image/cup.png',
            ...options
        });
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/stores/auth-store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuthHydration",
    ()=>useAuthHydration,
    "useAuthStore",
    ()=>useAuthStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const useAuthStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((set, get)=>({
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false,
        _hasHydrated: false,
        setHasHydrated: (state)=>{
            set({
                _hasHydrated: state
            });
        },
        login: (user, token)=>{
            set({
                user,
                token,
                isAuthenticated: true,
                isLoading: false
            });
        },
        logout: ()=>{
            set({
                user: null,
                token: null,
                isAuthenticated: false
            });
            // Clear any other persisted data if needed
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.removeItem("dailycup-wishlist");
                localStorage.removeItem("dailycup-recently-viewed");
            }
        },
        updateUser: (userData)=>{
            const currentUser = get().user;
            if (currentUser) {
                set({
                    user: {
                        ...currentUser,
                        ...userData
                    }
                });
            }
        },
        setLoading: (loading)=>{
            set({
                isLoading: loading
            });
        },
        addLoyaltyPoints: (points)=>{
            const currentUser = get().user;
            if (currentUser) {
                set({
                    user: {
                        ...currentUser,
                        loyaltyPoints: currentUser.loyaltyPoints + points
                    }
                });
            }
        },
        redeemPoints: (points)=>{
            const currentUser = get().user;
            if (currentUser && currentUser.loyaltyPoints >= points) {
                set({
                    user: {
                        ...currentUser,
                        loyaltyPoints: currentUser.loyaltyPoints - points
                    }
                });
                return true;
            }
            return false;
        }
    }), {
    name: "dailycup-auth",
    storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>localStorage),
    partialize: (state)=>({
            user: state.user,
            token: state.token,
            isAuthenticated: state.isAuthenticated
        }),
    onRehydrateStorage: ()=>(state)=>{
            state?.setHasHydrated(true);
        }
}));
function useAuthHydration() {
    _s();
    const hasHydrated = useAuthStore({
        "useAuthHydration.useAuthStore[hasHydrated]": (state)=>state._hasHydrated
    }["useAuthHydration.useAuthStore[hasHydrated]"]);
    const [isHydrated, setIsHydrated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(hasHydrated);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAuthHydration.useEffect": ()=>{
            // Subscribe to hydration state changes
            const unsubscribe = useAuthStore.subscribe({
                "useAuthHydration.useEffect.unsubscribe": (state)=>{
                    if (state._hasHydrated) {
                        setIsHydrated(true);
                    }
                }
            }["useAuthHydration.useEffect.unsubscribe"]);
            // Check if already hydrated
            if (useAuthStore.getState()._hasHydrated) {
                setIsHydrated(true);
            }
            return ({
                "useAuthHydration.useEffect": ()=>unsubscribe()
            })["useAuthHydration.useEffect"];
        }
    }["useAuthHydration.useEffect"], []);
    return isHydrated;
}
_s(useAuthHydration, "UqASjsIutG+2FmeWwGLM5ttBCmg=", false, function() {
    return [
        useAuthStore
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/pushManager.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PushNotificationManager",
    ()=>PushNotificationManager,
    "default",
    ()=>__TURBOPACK__default__export__,
    "pushManager",
    ()=>pushManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Push Notification Manager
 * Handles Web Push API subscriptions and permissions
 */ const VAPID_PUBLIC_KEY = ("TURBOPACK compile-time value", "BJZ2QjWbziK5U68pPrWDIcSB8Sm9ONFwVCi_U7LTJkyvh-Lp5nBMw1Pgq3SIaA0txvKVOHX0YdSQ5Qi8xn7e4wI") || '';
class PushNotificationManager {
    static instance;
    registration = null;
    constructor(){}
    static getInstance() {
        if (!PushNotificationManager.instance) {
            PushNotificationManager.instance = new PushNotificationManager();
        }
        return PushNotificationManager.instance;
    }
    /**
   * Check if push notifications are supported
   */ isSupported() {
        return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
    }
    /**
   * Get current notification permission
   */ getPermission() {
        if (!this.isSupported()) return 'denied';
        return Notification.permission;
    }
    /**
   * Request notification permission
   */ async requestPermission() {
        if (!this.isSupported()) {
            throw new Error('Push notifications are not supported');
        }
        const permission = await Notification.requestPermission();
        return permission;
    }
    /**
   * Initialize service worker registration
   */ async initialize(registration) {
        this.registration = registration;
    }
    /**
   * Convert VAPID public key to Uint8Array
   */ urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        for(let i = 0; i < rawData.length; ++i){
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    }
    /**
   * Subscribe to push notifications
   */ async subscribe() {
        if (!this.isSupported()) {
            throw new Error('Push notifications are not supported');
        }
        if (!this.registration) {
            throw new Error('Service worker not registered');
        }
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        try {
            // Check permission
            const permission = await this.requestPermission();
            if (permission !== 'granted') {
                console.log('Push notification permission denied');
                return null;
            }
            // CRITICAL: Unsubscribe from any existing subscription first
            // This prevents "different applicationServerKey" errors
            const existingSubscription = await this.registration.pushManager.getSubscription();
            if (existingSubscription) {
                console.log('[PushManager] Found existing subscription, unsubscribing...');
                const unsubscribed = await existingSubscription.unsubscribe();
                if (unsubscribed) {
                    console.log('[PushManager] Successfully unsubscribed from old subscription');
                } else {
                    console.warn('[PushManager] Failed to unsubscribe from old subscription');
                }
            }
            // Subscribe to push with new VAPID key
            const subscription = await this.registration.pushManager.subscribe({
                userVisibleOnly: true,
                // Cast to BufferSource to satisfy typing expected by the browser
                applicationServerKey: this.urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
            });
            // Convert to JSON
            const subscriptionData = subscription.toJSON();
            return {
                endpoint: subscriptionData.endpoint || '',
                keys: {
                    p256dh: subscriptionData.keys?.p256dh || '',
                    auth: subscriptionData.keys?.auth || ''
                }
            };
        } catch (error) {
            console.error('Failed to subscribe to push notifications:', error);
            throw error;
        }
    }
    /**
   * Unsubscribe from push notifications
   */ async unsubscribe() {
        if (!this.registration) {
            return false;
        }
        try {
            const subscription = await this.registration.pushManager.getSubscription();
            if (subscription) {
                await subscription.unsubscribe();
                return true;
            }
            return false;
        } catch (error) {
            console.error('Failed to unsubscribe from push notifications:', error);
            return false;
        }
    }
    /**
   * Get current subscription
   */ async getSubscription() {
        if (!this.registration) {
            return null;
        }
        try {
            return await this.registration.pushManager.getSubscription();
        } catch (error) {
            console.error('Failed to get push subscription:', error);
            return null;
        }
    }
    /**
   * Check if user is subscribed
   */ async isSubscribed() {
        const subscription = await this.getSubscription();
        return subscription !== null;
    }
    /**
   * Test notification (requires permission)
   */ async showTestNotification() {
        if (!this.isSupported()) {
            throw new Error('Notifications are not supported');
        }
        const permission = this.getPermission();
        if (permission !== 'granted') {
            throw new Error('Notification permission not granted');
        }
        if (!this.registration) {
            throw new Error('Service worker not registered');
        }
        const notifOptions = {
            body: 'Push notifications are working! 🎉',
            icon: '/assets/image/cup.png',
            badge: '/logo/cup-badge.png',
            tag: 'test-notification',
            vibrate: [
                200,
                100,
                200
            ],
            data: {
                url: '/menu'
            }
        };
        await this.registration.showNotification('DailyCup Test', notifOptions);
    }
}
const pushManager = PushNotificationManager.getInstance();
const __TURBOPACK__default__export__ = pushManager;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "APIError",
    ()=>APIError,
    "api",
    ()=>api,
    "default",
    ()=>__TURBOPACK__default__export__,
    "endpoints",
    ()=>endpoints
]);
/**
 * Centralized API Client for DailyCup
 * 
 * This module provides a standardized way to communicate with the backend.
 * Features:
 * - Automatic base URL from environment variables
 * - Automatic token injection for authenticated requests
 * - Centralized error handling
 * - Request/Response interceptors
 */ // Use Next.js rewrites to proxy API calls
// Always use /api prefix for client-side calls (rewrites handle routing)
const API_BASE_URL = ("TURBOPACK compile-time truthy", 1) ? '/api' // Client-side: always use Next.js rewrites
 : "TURBOPACK unreachable";
class APIError extends Error {
    status;
    data;
    constructor(message, status, data){
        super(message);
        this.name = 'APIError';
        this.status = status;
        this.data = data;
    }
}
// Get auth token from localStorage (client-side only)
function getAuthToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const authData = localStorage.getItem('dailycup-auth');
        if (authData) {
            const parsed = JSON.parse(authData);
            // Zustand persist stores data in { state: { ... } } structure
            return parsed?.state?.token || parsed?.token || null;
        }
    } catch (error) {
        console.error('Error reading auth token:', error);
        return null;
    }
    return null;
}
/**
 * Main API request function
 */ async function apiRequest(endpoint, config = {}) {
    const { method = 'GET', headers = {}, body, requiresAuth = false, timeout = 30000 } = config;
    // Build URL
    const url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}/${endpoint.replace(/^\//, '')}`;
    // Build headers
    const requestHeaders = {
        'Accept': 'application/json',
        'ngrok-skip-browser-warning': '69420',
        ...headers
    };
    // Add Content-Type: application/json if body is not FormData
    if (!(body instanceof FormData) && !requestHeaders['Content-Type']) {
        requestHeaders['Content-Type'] = 'application/json';
    }
    // Always add auth token if available (not just when requiresAuth=true)
    const token = getAuthToken();
    if (token) {
        requestHeaders['Authorization'] = `Bearer ${token}`;
    }
    // Build fetch options
    const fetchOptions = {
        method,
        headers: requestHeaders,
        credentials: 'include'
    };
    // Add body for non-GET requests
    if (body && method !== 'GET') {
        if (body instanceof FormData) {
            fetchOptions.body = body;
        } else {
            fetchOptions.body = JSON.stringify(body);
        }
    }
    // Create abort controller for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(()=>controller.abort(), timeout);
    fetchOptions.signal = controller.signal;
    try {
        const response = await fetch(url, fetchOptions);
        clearTimeout(timeoutId);
        // Parse response
        let data;
        const contentType = response.headers.get('content-type');
        if (contentType?.includes('application/json')) {
            data = await response.json();
        } else {
            data = await response.text();
        }
        // Handle HTTP errors
        if (!response.ok) {
            const errorData = data;
            throw new APIError(errorData?.message || errorData?.error || `HTTP Error ${response.status}`, response.status, data);
        }
        return data;
    } catch (error) {
        clearTimeout(timeoutId);
        const err = error;
        // Handle abort (timeout)
        if (err.name === 'AbortError') {
            throw new APIError('Request timeout', 408);
        }
        // Handle network errors
        if (err.name === 'TypeError' && err.message?.includes('fetch')) {
            throw new APIError('Network error - Backend may be offline', 0);
        }
        // Re-throw API errors
        if (error instanceof APIError) {
            throw error;
        }
        // Generic error
        throw new APIError(err.message || 'Unknown error', 500);
    }
}
const api = {
    get: (endpoint, config)=>apiRequest(endpoint, {
            ...config,
            method: 'GET'
        }),
    post: (endpoint, body, config)=>apiRequest(endpoint, {
            ...config,
            method: 'POST',
            body
        }),
    put: (endpoint, body, config)=>apiRequest(endpoint, {
            ...config,
            method: 'PUT',
            body
        }),
    delete: (endpoint, config)=>apiRequest(endpoint, {
            ...config,
            method: 'DELETE'
        }),
    patch: (endpoint, body, config)=>apiRequest(endpoint, {
            ...config,
            method: 'PATCH',
            body
        })
};
const endpoints = {
    // Products
    products: {
        list: ()=>'products.php',
        single: (id)=>`products.php?id=${id}`
    },
    // Categories
    categories: {
        list: ()=>'categories.php'
    },
    // Auth
    auth: {
        login: ()=>'auth/login.php',
        register: ()=>'auth/register.php',
        logout: ()=>'auth/logout.php',
        profile: ()=>'auth/profile.php'
    },
    // Orders
    orders: {
        create: ()=>'create_order.php',
        get: (id)=>`get_order.php?id=${id}`,
        list: ()=>'orders.php',
        pay: ()=>'pay_order.php'
    },
    // Admin
    admin: {
        dashboard: ()=>'admin/dashboard.php',
        products: ()=>'admin/products.php',
        orders: ()=>'admin/orders.php',
        users: ()=>'admin/users.php',
        analytics: ()=>'admin/analytics.php?action=summary',
        customers: ()=>'admin/customers.php?action=list',
        customer: (id)=>`admin/customers.php?action=detail&id=${id}`,
        broadcast: ()=>'admin/broadcast.php?action=send',
        reports: ()=>'admin/reports.php?action=top'
    },
    integrations: {
        twilio: {
            settings: ()=>'integrations/twilio.php?action=settings',
            saveSettings: ()=>'integrations/twilio.php?action=settings',
            send: ()=>'integrations/twilio.php?action=send',
            logs: ()=>'integrations/twilio.php?action=logs',
            providerSettings: ()=>'integrations/twilio.php?action=provider_settings',
            workerStatus: ()=>'integrations/twilio.php?action=logs&action2=worker_status',
            runWorker: ()=>'integrations/twilio.php?action=run_worker',
            testAlert: ()=>'integrations/twilio.php?action=alerts&test=1'
        },
        send: {
            send: ()=>'integrations/send.php?action=send'
        }
    }
};
const __TURBOPACK__default__export__ = api;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/NotificationProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotificationProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$notificationClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/notificationClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/stores/auth-store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$pushManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/pushManager.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api-client.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function NotificationProvider({ children }) {
    _s();
    const { token, user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])();
    const [pushSetupAttempted, setPushSetupAttempted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotificationProvider.useEffect": ()=>{
            if (!token || !user) {
                // Disconnect if user logs out
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$notificationClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disconnectNotificationClient"])();
                return;
            }
            // Request browser notification permission
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$notificationClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requestNotificationPermission"])();
            // TODO: SSE connection disabled temporarily due to stream.php accessibility issues
            // Will re-enable after fixing Apache SSE configuration
            // Connect to SSE stream
            // const client = getNotificationClient(user.id?.toString());
            // client.connect(token);
            console.log('[Notifications] Using polling mode (SSE disabled temporarily)');
            // Setup push notifications (only once per session)
            if (!pushSetupAttempted) {
                setupPushNotifications();
                setPushSetupAttempted(true);
            }
            // Cleanup on unmount or token change
            return ({
                "NotificationProvider.useEffect": ()=>{
                // client.disconnect();
                }
            })["NotificationProvider.useEffect"];
        }
    }["NotificationProvider.useEffect"], [
        token,
        user
    ]);
    const setupPushNotifications = async ()=>{
        try {
            // Check if push is supported
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$pushManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isSupported()) {
                console.log('Push notifications not supported');
                return;
            }
            // CRITICAL: Always unsubscribe from ALL existing subscriptions first
            // This completely clears any VAPID key conflicts
            try {
                const registration = await navigator.serviceWorker.ready;
                const subscription = await registration.pushManager.getSubscription();
                if (subscription) {
                    console.log('[Notifications] Found existing subscription, force unsubscribing...');
                    const unsubscribed = await subscription.unsubscribe();
                    if (unsubscribed) {
                        console.log('[Notifications] ✓ Successfully cleared old subscription');
                    } else {
                        console.warn('[Notifications] ⚠ Failed to unsubscribe, will try anyway');
                    }
                    // Wait a bit to ensure unsubscribe completes
                    await new Promise((resolve)=>setTimeout(resolve, 500));
                } else {
                    console.log('[Notifications] No existing subscription found');
                }
            } catch (e) {
                console.warn('[Notifications] Error checking/clearing subscription:', e);
            // Continue anyway - might be first time
            }
            // Check user preferences (requires authentication)
            try {
                const prefResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/notifications/preferences.php', {
                    requiresAuth: true
                });
                const preferences = prefResponse.data?.preferences;
                // Only auto-subscribe if user has push enabled in preferences
                if (!preferences?.push_enabled) {
                    console.log('Push notifications disabled in user preferences');
                    return;
                }
            } catch (prefError) {
                // If preferences endpoint fails, continue with push setup anyway
                console.log('Could not fetch preferences, continuing with push setup:', prefError);
            }
            // Get notification permission
            const permission = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$pushManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getPermission();
            if (permission === 'granted') {
                // Auto-subscribe user
                const registration = await navigator.serviceWorker.ready;
                await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$pushManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].initialize(registration);
                const subscriptionData = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$pushManager$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].subscribe();
                if (subscriptionData) {
                    // Send subscription to backend (plain payload to satisfy API typing)
                    const payload = {
                        endpoint: subscriptionData.endpoint,
                        keys: subscriptionData.keys
                    };
                    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/notifications/push_subscribe.php', payload);
                    console.log('✅ Subscribed to push notifications');
                }
            } else if (permission === 'default') {
                console.log('Push permission not yet requested');
            }
        } catch (error) {
            console.error('Failed to setup push notifications:', error);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(NotificationProvider, "PfgO6l84vutB1VMBC8E5zpJKDbY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"]
    ];
});
_c = NotificationProvider;
var _c;
__turbopack_context__.k.register(_c, "NotificationProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/analytics/sentry.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Sentry Integration for Error Tracking
 * 
 * Sentry provides FREE tier with 5K errors/month
 * Get your DSN from https://sentry.io
 */ // Note: For full Sentry SDK, install with: npm install @sentry/nextjs
// This is a lightweight alternative that works without the full SDK
__turbopack_context__.s([
    "initSentry",
    ()=>initSentry,
    "sentry",
    ()=>sentry
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
class LightweightSentry {
    dsn = null;
    config = null;
    user = undefined;
    tags = {};
    init(config) {
        this.dsn = config.dsn;
        this.config = config;
        // Add global error handler
        if ("TURBOPACK compile-time truthy", 1) {
            window.addEventListener('error', (event)=>{
                this.captureException(event.error || new Error(event.message));
            });
            window.addEventListener('unhandledrejection', (event)=>{
                this.captureException(event.reason);
            });
        }
    }
    setUser(user) {
        this.user = user;
    }
    setTag(key, value) {
        this.tags[key] = value;
    }
    setTags(tags) {
        this.tags = {
            ...this.tags,
            ...tags
        };
    }
    async sendEvent(event) {
        if (!this.dsn) {
            console.warn('[Sentry] DSN not configured. Event not sent:', event);
            return;
        }
        // Parse DSN to get the endpoint
        const dsnMatch = this.dsn.match(/https:\/\/(.+?)@(.+?)\/(.+)/);
        if (!dsnMatch) {
            console.error('[Sentry] Invalid DSN format');
            return;
        }
        const [, publicKey, host, projectId] = dsnMatch;
        const endpoint = `https://${host}/api/${projectId}/store/`;
        try {
            await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Sentry-Auth': `Sentry sentry_version=7, sentry_key=${publicKey}`
                },
                body: JSON.stringify({
                    ...event,
                    sdk: {
                        name: 'dailycup-sentry',
                        version: '1.0.0'
                    },
                    environment: this.config?.environment || 'production',
                    release: this.config?.release,
                    user: this.user,
                    tags: this.tags
                })
            });
        } catch (error) {
            // Silently fail - we don't want error tracking to break the app
            console.warn('[Sentry] Failed to send event:', error);
        }
    }
    captureException(error, context) {
        const event = {
            level: 'error',
            exception: {
                type: error.name,
                value: error.message,
                stacktrace: error.stack
            },
            tags: {
                ...this.tags,
                ...context?.tags
            },
            extra: context?.extra,
            timestamp: new Date().toISOString(),
            platform: 'javascript',
            contexts: {
                browser: typeof navigator !== 'undefined' ? {
                    name: navigator.userAgent
                } : undefined,
                os: typeof navigator !== 'undefined' ? {
                    name: navigator.platform
                } : undefined
            }
        };
        // Log to console in development
        if ("TURBOPACK compile-time truthy", 1) {
            console.error('[Sentry] Captured exception:', error, context);
        }
        this.sendEvent(event);
    }
    captureMessage(message, level = 'info', context) {
        const event = {
            message,
            level,
            tags: {
                ...this.tags,
                ...context?.tags
            },
            extra: context?.extra,
            timestamp: new Date().toISOString(),
            platform: 'javascript'
        };
        if ("TURBOPACK compile-time truthy", 1) {
            console.log(`[Sentry][${level}]`, message, context);
        }
        this.sendEvent(event);
    }
    // Breadcrumbs for better debugging context
    breadcrumbs = [];
    addBreadcrumb(breadcrumb) {
        this.breadcrumbs.push({
            ...breadcrumb,
            timestamp: new Date().toISOString()
        });
        // Keep only last 50 breadcrumbs
        if (this.breadcrumbs.length > 50) {
            this.breadcrumbs.shift();
        }
    }
    // Performance monitoring (basic)
    startTransaction(name, op) {
        const startTime = performance.now();
        return {
            name,
            op,
            finish: ()=>{
                const duration = performance.now() - startTime;
                this.addBreadcrumb({
                    category: 'transaction',
                    message: `${op}: ${name}`,
                    data: {
                        duration_ms: duration
                    }
                });
            }
        };
    }
}
const sentry = new LightweightSentry();
function initSentry() {
    const dsn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_SENTRY_DSN;
    if (!dsn) {
        console.warn('[Sentry] NEXT_PUBLIC_SENTRY_DSN not configured');
        return;
    }
    sentry.init({
        dsn,
        environment: ("TURBOPACK compile-time value", "development"),
        release: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_APP_VERSION,
        tracesSampleRate: 0.1
    });
} // Note: For full Sentry error boundary integration, use @sentry/nextjs
 // This lightweight implementation focuses on error capturing only
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/analytics/web-vitals.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Web Vitals Monitoring
 * 
 * Tracks Core Web Vitals for performance monitoring
 * Free to use - data can be sent to GA4 or any analytics service
 */ __turbopack_context__.s([
    "initWebVitals",
    ()=>initWebVitals,
    "performance",
    ()=>performance
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// Thresholds based on Google's recommendations
const thresholds = {
    CLS: {
        good: 0.1,
        poor: 0.25
    },
    FCP: {
        good: 1800,
        poor: 3000
    },
    FID: {
        good: 100,
        poor: 300
    },
    INP: {
        good: 200,
        poor: 500
    },
    LCP: {
        good: 2500,
        poor: 4000
    },
    TTFB: {
        good: 800,
        poor: 1800
    }
};
function getRating(name, value) {
    const threshold = thresholds[name];
    if (value <= threshold.good) return 'good';
    if (value <= threshold.poor) return 'needs-improvement';
    return 'poor';
}
// Report to Google Analytics
function reportToGA(metric) {
    if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.gtag) {
        window.gtag('event', metric.name, {
            event_category: 'Web Vitals',
            event_label: metric.id,
            value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
            non_interaction: true,
            metric_rating: metric.rating
        });
    }
}
// Report to custom endpoint
async function reportToEndpoint(metric, endpoint) {
    try {
        await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                ...metric,
                url: window.location.href,
                userAgent: navigator.userAgent,
                timestamp: new Date().toISOString()
            }),
            // Use keepalive to ensure the request completes even if the page unloads
            keepalive: true
        });
    } catch (error) {
        console.warn('[WebVitals] Failed to report metric:', error);
    }
}
function initWebVitals(options) {
    const { reportToGA: shouldReportToGA = true, customEndpoint, onMetric } = options || {};
    // Dynamic import web-vitals library
    __turbopack_context__.A("[project]/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript, async loader)").then(({ onCLS, onFCP, onINP, onLCP, onTTFB })=>{
        const handleMetric = (metric)=>{
            const webVitalMetric = {
                name: metric.name,
                value: metric.value,
                rating: getRating(metric.name, metric.value),
                delta: metric.delta,
                id: metric.id,
                navigationType: metric.navigationType
            };
            // Report to GA4
            if (shouldReportToGA) {
                reportToGA(webVitalMetric);
            }
            // Report to custom endpoint
            if (customEndpoint) {
                reportToEndpoint(webVitalMetric, customEndpoint);
            }
            // Custom handler
            if (onMetric) {
                onMetric(webVitalMetric);
            }
            // Log in development
            if ("TURBOPACK compile-time truthy", 1) {
                console.log(`[WebVitals] ${metric.name}:`, {
                    value: metric.value,
                    rating: webVitalMetric.rating
                });
            }
        };
        onCLS(handleMetric);
        onFCP(handleMetric);
        onINP(handleMetric);
        onLCP(handleMetric);
        onTTFB(handleMetric);
    }).catch((error)=>{
        console.warn('[WebVitals] Failed to load web-vitals library:', error);
    });
}
const performance = {
    // Measure time for an operation
    measure: async (name, fn)=>{
        const start = globalThis.performance.now();
        try {
            return await fn();
        } finally{
            const duration = globalThis.performance.now() - start;
            if ("TURBOPACK compile-time truthy", 1) {
                console.log(`[Performance] ${name}: ${duration.toFixed(2)}ms`);
            }
        }
    },
    // Mark a point in time
    mark: (name)=>{
        if (typeof globalThis.performance !== 'undefined') {
            globalThis.performance.mark(name);
        }
    },
    // Measure between two marks
    measureBetween: (name, startMark, endMark)=>{
        if (typeof globalThis.performance !== 'undefined') {
            try {
                globalThis.performance.measure(name, startMark, endMark);
                const entries = globalThis.performance.getEntriesByName(name);
                const lastEntry = entries[entries.length - 1];
                return lastEntry?.duration;
            } catch  {
                return undefined;
            }
        }
        return undefined;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/serviceWorker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Service Worker Registration and Management
__turbopack_context__.s([
    "checkOfflineStatus",
    ()=>checkOfflineStatus,
    "clearAllCaches",
    ()=>clearAllCaches,
    "formatBytes",
    ()=>formatBytes,
    "getCacheSize",
    ()=>getCacheSize,
    "registerServiceWorker",
    ()=>registerServiceWorker,
    "subscribeToOnlineStatus",
    ()=>subscribeToOnlineStatus,
    "unregisterServiceWorker",
    ()=>unregisterServiceWorker,
    "updateServiceWorker",
    ()=>updateServiceWorker
]);
const registerServiceWorker = async ()=>{
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !('serviceWorker' in navigator)) {
        console.log('Service Worker not supported');
        return null;
    }
    try {
        const registration = await navigator.serviceWorker.register('/sw.js', {
            scope: '/',
            updateViaCache: 'none'
        });
        console.log('Service Worker registered:', registration);
        // Check for updates periodically
        setInterval(()=>{
            registration.update();
        }, 60 * 60 * 1000); // Check every hour
        // Handle updates
        registration.addEventListener('updatefound', ()=>{
            const newWorker = registration.installing;
            if (!newWorker) return;
            newWorker.addEventListener('statechange', ()=>{
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                    // New service worker available
                    console.log('New service worker available');
                    // Notify user about update
                    if (("TURBOPACK compile-time value", "object") !== 'undefined' && window.dispatchEvent) {
                        window.dispatchEvent(new CustomEvent('sw-update-available', {
                            detail: {
                                registration
                            }
                        }));
                    }
                }
            });
        });
        return registration;
    } catch (error) {
        console.error('Service Worker registration failed:', error);
        return null;
    }
};
const unregisterServiceWorker = async ()=>{
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !('serviceWorker' in navigator)) {
        return false;
    }
    try {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration) {
            const success = await registration.unregister();
            console.log('Service Worker unregistered:', success);
            return success;
        }
        return false;
    } catch (error) {
        console.error('Service Worker unregistration failed:', error);
        return false;
    }
};
const updateServiceWorker = (registration)=>{
    const waitingWorker = registration.waiting;
    if (!waitingWorker) return;
    // Tell the waiting service worker to skip waiting
    waitingWorker.postMessage({
        type: 'SKIP_WAITING'
    });
    // Reload the page when the new service worker takes control
    navigator.serviceWorker.addEventListener('controllerchange', ()=>{
        window.location.reload();
    });
};
const checkOfflineStatus = ()=>{
    return ("TURBOPACK compile-time value", "object") !== 'undefined' && !navigator.onLine;
};
const subscribeToOnlineStatus = (callback)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const handleOnline = ()=>callback(true);
    const handleOffline = ()=>callback(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return ()=>{
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
    };
};
const clearAllCaches = async ()=>{
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !('caches' in window)) return;
    try {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map((cacheName)=>caches.delete(cacheName)));
        console.log('All caches cleared');
    } catch (error) {
        console.error('Failed to clear caches:', error);
    }
};
const getCacheSize = async ()=>{
    if (("TURBOPACK compile-time value", "object") === 'undefined' || !('caches' in window)) return 0;
    try {
        const cacheNames = await caches.keys();
        let totalSize = 0;
        for (const cacheName of cacheNames){
            const cache = await caches.open(cacheName);
            const requests = await cache.keys();
            for (const request of requests){
                const response = await cache.match(request);
                if (response) {
                    const blob = await response.blob();
                    totalSize += blob.size;
                }
            }
        }
        return totalSize;
    } catch (error) {
        console.error('Failed to get cache size:', error);
        return 0;
    }
};
const formatBytes = (bytes)=>{
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = [
        'Bytes',
        'KB',
        'MB',
        'GB'
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/providers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Providers",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$query$2d$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/query-client.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toast$2d$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/toast-provider.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$error$2d$boundary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/error-boundary.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/CartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ClientUI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ClientUI.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$NotificationProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/NotificationProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$ui$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/stores/ui-store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$analytics$2f$sentry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/analytics/sentry.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$analytics$2f$web$2d$vitals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/analytics/web-vitals.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$serviceWorker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/serviceWorker.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
// Initialize Sentry error tracking
if ("TURBOPACK compile-time truthy", 1) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$analytics$2f$sentry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initSentry"])();
}
function ThemeProvider({ children }) {
    _s();
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$ui$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUIStore"])({
        "ThemeProvider.useUIStore[theme]": (state)=>state.theme
    }["ThemeProvider.useUIStore[theme]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeProvider.useEffect": ()=>{
            const root = document.documentElement;
            if (theme === "system") {
                const systemDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                root.classList.toggle("dark", systemDark);
            } else {
                root.classList.toggle("dark", theme === "dark");
            }
        }
    }["ThemeProvider.useEffect"], [
        theme
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(ThemeProvider, "imsnAG4hHV+hd3MMvKuNmgeza74=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$ui$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUIStore"]
    ];
});
_c = ThemeProvider;
// Analytics initialization component
function AnalyticsProvider({ children }) {
    _s1();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AnalyticsProvider.useEffect": ()=>{
            // Initialize Web Vitals monitoring
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$analytics$2f$web$2d$vitals$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initWebVitals"])({
                reportToGA: !!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_GA_MEASUREMENT_ID
            });
            // Register Service Worker for PWA
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$serviceWorker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerServiceWorker"])();
        }
    }["AnalyticsProvider.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s1(AnalyticsProvider, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c1 = AnalyticsProvider;
function Providers({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$error$2d$boundary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorBoundary"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$query$2d$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["QueryProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CartProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ThemeProvider, {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AnalyticsProvider, {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$NotificationProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    id: "__client_ui_root",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ClientUI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/app/providers.tsx",
                                        lineNumber: 62,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/providers.tsx",
                                    lineNumber: 61,
                                    columnNumber: 17
                                }, this),
                                children,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toast$2d$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ToastProvider"], {}, void 0, false, {
                                    fileName: "[project]/app/providers.tsx",
                                    lineNumber: 65,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/providers.tsx",
                            lineNumber: 59,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/providers.tsx",
                        lineNumber: 58,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/providers.tsx",
                    lineNumber: 57,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/providers.tsx",
                lineNumber: 56,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/providers.tsx",
            lineNumber: 55,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/providers.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_c2 = Providers;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ThemeProvider");
__turbopack_context__.k.register(_c1, "AnalyticsProvider");
__turbopack_context__.k.register(_c2, "Providers");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/OfflineBanner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OfflineBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wifi$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wifi.js [app-client] (ecmascript) <export default as Wifi>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WifiOff$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wifi-off.js [app-client] (ecmascript) <export default as WifiOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function OfflineBanner() {
    _s();
    const [isOnline, setIsOnline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [showBanner, setShowBanner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfflineBanner.useEffect": ()=>{
            // Initial check
            setIsOnline(navigator.onLine);
            const handleOnline = {
                "OfflineBanner.useEffect.handleOnline": ()=>{
                    setIsOnline(true);
                    setShowBanner(true);
                    // Auto hide after 3 seconds
                    setTimeout({
                        "OfflineBanner.useEffect.handleOnline": ()=>{
                            setShowBanner(false);
                        }
                    }["OfflineBanner.useEffect.handleOnline"], 3000);
                }
            }["OfflineBanner.useEffect.handleOnline"];
            const handleOffline = {
                "OfflineBanner.useEffect.handleOffline": ()=>{
                    setIsOnline(false);
                    setShowBanner(true);
                }
            }["OfflineBanner.useEffect.handleOffline"];
            window.addEventListener('online', handleOnline);
            window.addEventListener('offline', handleOffline);
            return ({
                "OfflineBanner.useEffect": ()=>{
                    window.removeEventListener('online', handleOnline);
                    window.removeEventListener('offline', handleOffline);
                }
            })["OfflineBanner.useEffect"];
        }
    }["OfflineBanner.useEffect"], []);
    if (!showBanner) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isOnline ? 'bg-green-500 text-white' : 'bg-orange-500 text-white'}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 py-3 flex items-center justify-between",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: isOnline ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wifi$3e$__["Wifi"], {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/components/OfflineBanner.tsx",
                                lineNumber: 52,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-medium",
                                children: "You're back online!"
                            }, void 0, false, {
                                fileName: "[project]/components/OfflineBanner.tsx",
                                lineNumber: 53,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WifiOff$3e$__["WifiOff"], {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/components/OfflineBanner.tsx",
                                lineNumber: 57,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-medium",
                                children: "You're offline. Some features may be limited."
                            }, void 0, false, {
                                fileName: "[project]/components/OfflineBanner.tsx",
                                lineNumber: 58,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                }, void 0, false, {
                    fileName: "[project]/components/OfflineBanner.tsx",
                    lineNumber: 49,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>setShowBanner(false),
                    className: "p-1 hover:bg-white/20 rounded transition-colors",
                    "aria-label": "Close",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                        className: "w-5 h-5"
                    }, void 0, false, {
                        fileName: "[project]/components/OfflineBanner.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/OfflineBanner.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/OfflineBanner.tsx",
            lineNumber: 48,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/OfflineBanner.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_s(OfflineBanner, "LnXAlNhTW33cPyfn3Yb0YBhCeOk=");
_c = OfflineBanner;
var _c;
__turbopack_context__.k.register(_c, "OfflineBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/PWAInstallPrompt.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PWAInstallPrompt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Share$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/share.js [app-client] (ecmascript) <export default as Share>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function PWAInstallPrompt() {
    _s();
    const [deferredPrompt, setDeferredPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showPrompt, setShowPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isIOS, setIsIOS] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isStandalone, setIsStandalone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PWAInstallPrompt.useEffect": ()=>{
            // Check if already installed
            const isInStandaloneMode = window.matchMedia('(display-mode: standalone)').matches;
            setIsStandalone(isInStandaloneMode);
            // Check if iOS
            const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
            setIsIOS(iOS);
            // Check if prompt was dismissed before
            const promptDismissed = localStorage.getItem('pwa-prompt-dismissed');
            if (promptDismissed) {
                const dismissedTime = parseInt(promptDismissed);
                const daysSinceDismissed = (Date.now() - dismissedTime) / (1000 * 60 * 60 * 24);
                // Show again after 7 days
                if (daysSinceDismissed < 7) {
                    return;
                }
            }
            // Listen for beforeinstallprompt event
            const handleBeforeInstallPrompt = {
                "PWAInstallPrompt.useEffect.handleBeforeInstallPrompt": (e)=>{
                    e.preventDefault();
                    setDeferredPrompt(e);
                    // Show prompt after 30 seconds
                    setTimeout({
                        "PWAInstallPrompt.useEffect.handleBeforeInstallPrompt": ()=>{
                            setShowPrompt(true);
                        }
                    }["PWAInstallPrompt.useEffect.handleBeforeInstallPrompt"], 30000);
                }
            }["PWAInstallPrompt.useEffect.handleBeforeInstallPrompt"];
            window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
            // Show iOS prompt after 30 seconds if on iOS and not standalone
            if (iOS && !isInStandaloneMode && !promptDismissed) {
                setTimeout({
                    "PWAInstallPrompt.useEffect": ()=>{
                        setShowPrompt(true);
                    }
                }["PWAInstallPrompt.useEffect"], 30000);
            }
            return ({
                "PWAInstallPrompt.useEffect": ()=>{
                    window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
                }
            })["PWAInstallPrompt.useEffect"];
        }
    }["PWAInstallPrompt.useEffect"], []);
    const handleInstallClick = async ()=>{
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
            console.log('User accepted the install prompt');
        } else {
            console.log('User dismissed the install prompt');
        }
        setDeferredPrompt(null);
        setShowPrompt(false);
    };
    const handleDismiss = ()=>{
        setShowPrompt(false);
        localStorage.setItem('pwa-prompt-dismissed', Date.now().toString());
    };
    if (isStandalone || !showPrompt) {
        return null;
    }
    if (isIOS) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 animate-slide-up",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleDismiss,
                        className: "absolute top-4 right-4 p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors",
                        "aria-label": "Close",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            className: "w-5 h-5"
                        }, void 0, false, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 97,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4 mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-16 bg-[#a15e3f] rounded-2xl flex items-center justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/assets/image/cup.png",
                                    alt: "DailyCup",
                                    className: "w-12 h-12"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 102,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                lineNumber: 101,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-bold text-lg",
                                        children: "Install DailyCup"
                                    }, void 0, false, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 105,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600 dark:text-gray-400",
                                        children: "Get quick access on your iPhone"
                                    }, void 0, false, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 106,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                lineNumber: 104,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-medium mb-3 flex items-center gap-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-blue-600 dark:text-blue-400",
                                    children: "How to install:"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 112,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                lineNumber: 111,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                className: "text-sm text-gray-700 dark:text-gray-300 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex items-start gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold",
                                                children: "1."
                                            }, void 0, false, {
                                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                                lineNumber: 116,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    "Tap the ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Share$3e$__["Share"], {
                                                        className: "w-4 h-4 inline-block mx-1"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                                        lineNumber: 117,
                                                        columnNumber: 31
                                                    }, this),
                                                    " Share button below"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                                lineNumber: 117,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 115,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex items-start gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold",
                                                children: "2."
                                            }, void 0, false, {
                                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                                lineNumber: 120,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: 'Scroll down and tap "Add to Home Screen"'
                                            }, void 0, false, {
                                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                                lineNumber: 121,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 119,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "flex items-start gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-bold",
                                                children: "3."
                                            }, void 0, false, {
                                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                                lineNumber: 124,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: 'Tap "Add" in the top right corner'
                                            }, void 0, false, {
                                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                                lineNumber: 125,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 123,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleDismiss,
                        className: "w-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 py-3 rounded-xl font-semibold hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors",
                        children: "Maybe Later"
                    }, void 0, false, {
                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                        lineNumber: 130,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/PWAInstallPrompt.tsx",
                lineNumber: 91,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/PWAInstallPrompt.tsx",
            lineNumber: 90,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 animate-slide-up",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: handleDismiss,
                    className: "absolute top-4 right-4 p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors",
                    "aria-label": "Close",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                        className: "w-5 h-5"
                    }, void 0, false, {
                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                        lineNumber: 149,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                    lineNumber: 144,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4 mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-16 h-16 bg-[#a15e3f] rounded-2xl flex items-center justify-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/assets/image/cup.png",
                                alt: "DailyCup",
                                className: "w-12 h-12"
                            }, void 0, false, {
                                fileName: "[project]/components/PWAInstallPrompt.tsx",
                                lineNumber: 154,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 153,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "font-bold text-lg",
                                    children: "Install DailyCup"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 157,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600 dark:text-gray-400",
                                    children: "Access faster and work offline"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 158,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 156,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                    lineNumber: 152,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-3 mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-8 h-8 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                        className: "w-4 h-4 text-green-600 dark:text-green-400"
                                    }, void 0, false, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 165,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 164,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-700 dark:text-gray-300",
                                    children: "Works offline"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 167,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 163,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-8 h-8 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-blue-600 dark:text-blue-400",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M13 10V3L4 14h7v7l9-11h-7z"
                                        }, void 0, false, {
                                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                                            lineNumber: 172,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 171,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 170,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-700 dark:text-gray-300",
                                    children: "Lightning fast"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 175,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 169,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-8 h-8 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-purple-600 dark:text-purple-400",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                                        }, void 0, false, {
                                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                                            lineNumber: 180,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/PWAInstallPrompt.tsx",
                                        lineNumber: 179,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-700 dark:text-gray-300",
                                    children: "Like a native app"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 183,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 177,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                    lineNumber: 162,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleInstallClick,
                            className: "flex-1 bg-[#a15e3f] text-white py-3 rounded-xl font-semibold hover:bg-[#8a4f35] transition-colors flex items-center justify-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                                    lineNumber: 192,
                                    columnNumber: 13
                                }, this),
                                "Install"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 188,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleDismiss,
                            className: "px-6 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 py-3 rounded-xl font-semibold hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors",
                            children: "Later"
                        }, void 0, false, {
                            fileName: "[project]/components/PWAInstallPrompt.tsx",
                            lineNumber: 195,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/PWAInstallPrompt.tsx",
                    lineNumber: 187,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/PWAInstallPrompt.tsx",
            lineNumber: 143,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/PWAInstallPrompt.tsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
_s(PWAInstallPrompt, "uhrM+U/m9sNA4X3V7eJ2IaPkzmc=");
_c = PWAInstallPrompt;
var _c;
__turbopack_context__.k.register(_c, "PWAInstallPrompt");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/UpdatePrompt.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>UpdatePrompt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$serviceWorker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/serviceWorker.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function UpdatePrompt() {
    _s();
    const [registration, setRegistration] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showPrompt, setShowPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UpdatePrompt.useEffect": ()=>{
            const handleSWUpdate = {
                "UpdatePrompt.useEffect.handleSWUpdate": (event)=>{
                    setRegistration(event.detail.registration);
                    setShowPrompt(true);
                }
            }["UpdatePrompt.useEffect.handleSWUpdate"];
            window.addEventListener('sw-update-available', handleSWUpdate);
            return ({
                "UpdatePrompt.useEffect": ()=>{
                    window.removeEventListener('sw-update-available', handleSWUpdate);
                }
            })["UpdatePrompt.useEffect"];
        }
    }["UpdatePrompt.useEffect"], []);
    const handleUpdate = ()=>{
        if (registration) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$serviceWorker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateServiceWorker"])(registration);
        }
    };
    const handleDismiss = ()=>{
        setShowPrompt(false);
    };
    if (!showPrompt) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed top-4 left-4 right-4 md:left-auto md:right-4 md:w-96 bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 animate-slide-down",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: handleDismiss,
                    className: "absolute top-3 right-3 p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors",
                    "aria-label": "Close",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                        className: "w-4 h-4"
                    }, void 0, false, {
                        fileName: "[project]/components/UpdatePrompt.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/UpdatePrompt.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pr-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3 mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                        className: "w-5 h-5 text-blue-600 dark:text-blue-400"
                                    }, void 0, false, {
                                        fileName: "[project]/components/UpdatePrompt.tsx",
                                        lineNumber: 50,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/UpdatePrompt.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-bold text-sm",
                                            children: "Update Available"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UpdatePrompt.tsx",
                                            lineNumber: 53,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-600 dark:text-gray-400",
                                            children: "A new version is ready"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UpdatePrompt.tsx",
                                            lineNumber: 54,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UpdatePrompt.tsx",
                                    lineNumber: 52,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/UpdatePrompt.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleUpdate,
                                    className: "flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors",
                                    children: "Update Now"
                                }, void 0, false, {
                                    fileName: "[project]/components/UpdatePrompt.tsx",
                                    lineNumber: 59,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleDismiss,
                                    className: "px-4 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 py-2 rounded-lg text-sm font-semibold hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors",
                                    children: "Later"
                                }, void 0, false, {
                                    fileName: "[project]/components/UpdatePrompt.tsx",
                                    lineNumber: 65,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/UpdatePrompt.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/UpdatePrompt.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/UpdatePrompt.tsx",
            lineNumber: 38,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/UpdatePrompt.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_s(UpdatePrompt, "ZXbgQrOFEIjbdaHwZ21P+Zco+2s=");
_c = UpdatePrompt;
var _c;
__turbopack_context__.k.register(_c, "UpdatePrompt");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ChatWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ChatWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/stores/auth-store.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ChatWidget() {
    _s();
    const { isAuthenticated, user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [conversations, setConversations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedConv, setSelectedConv] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [messageInput, setMessageInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [newChatSubject, setNewChatSubject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [showNewChat, setShowNewChat] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [sending, setSending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatWidget.useEffect": ()=>{
            if (isAuthenticated && isOpen) {
                fetchConversations();
                const interval = setInterval(fetchConversations, 5000);
                return ({
                    "ChatWidget.useEffect": ()=>clearInterval(interval)
                })["ChatWidget.useEffect"];
            }
        }
    }["ChatWidget.useEffect"], [
        isAuthenticated,
        isOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatWidget.useEffect": ()=>{
            if (selectedConv) {
                fetchMessages(selectedConv.id);
                const interval = setInterval({
                    "ChatWidget.useEffect.interval": ()=>fetchMessages(selectedConv.id)
                }["ChatWidget.useEffect.interval"], 3000);
                return ({
                    "ChatWidget.useEffect": ()=>clearInterval(interval)
                })["ChatWidget.useEffect"];
            }
        }
    }["ChatWidget.useEffect"], [
        selectedConv
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatWidget.useEffect": ()=>{
            scrollToBottom();
        }
    }["ChatWidget.useEffect"], [
        messages
    ]);
    const scrollToBottom = ()=>{
        messagesEndRef.current?.scrollIntoView({
            behavior: 'smooth'
        });
    };
    const fetchConversations = async ()=>{
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].get('/chat/conversations.php', {
                requiresAuth: true
            });
            if (response.success) {
                setConversations(response.conversations);
                if (response.conversations.length > 0 && !selectedConv) {
                    setSelectedConv(response.conversations[0]);
                }
            }
        } catch (error) {
            console.error('Failed to fetch conversations:', error);
        }
    };
    const fetchMessages = async (convId)=>{
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].get(`/chat/messages.php?conversation_id=${convId}`, {
                requiresAuth: true
            });
            if (response.success) {
                setMessages(response.messages);
            }
        } catch (error) {
            console.error('Failed to fetch messages:', error);
        }
    };
    const createNewChat = async ()=>{
        if (!newChatSubject.trim() || !messageInput.trim()) {
            alert('Please enter subject and message');
            return;
        }
        setSending(true);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post('/chat/conversations.php', {
                subject: newChatSubject,
                message: messageInput
            }, {
                requiresAuth: true
            });
            if (response.success) {
                setShowNewChat(false);
                setNewChatSubject('');
                setMessageInput('');
                fetchConversations();
            }
        } catch (error) {
            console.error('Failed to create chat:', error);
            alert('Failed to create chat');
        } finally{
            setSending(false);
        }
    };
    const sendMessage = async ()=>{
        if (!messageInput.trim() || !selectedConv) return;
        setSending(true);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post('/chat/messages.php', {
                conversation_id: selectedConv.id,
                message: messageInput
            }, {
                requiresAuth: true
            });
            if (response.success) {
                setMessageInput('');
                fetchMessages(selectedConv.id);
            }
        } catch (error) {
            console.error('Failed to send message:', error);
        } finally{
            setSending(false);
        }
    };
    const totalUnread = conversations.reduce((sum, conv)=>sum + conv.unread_count, 0);
    if (!isAuthenticated) {
        return null; // Don't show widget if not logged in
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setIsOpen(!isOpen),
                className: "fixed bottom-6 right-6 w-16 h-16 bg-[#a97456] text-white rounded-full shadow-2xl hover:bg-[#8f6249] transition-all flex items-center justify-center z-50",
                children: isOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                    className: "bi bi-x-lg text-2xl"
                }, void 0, false, {
                    fileName: "[project]/components/ChatWidget.tsx",
                    lineNumber: 146,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                            className: "bi bi-chat-dots-fill text-2xl"
                        }, void 0, false, {
                            fileName: "[project]/components/ChatWidget.tsx",
                            lineNumber: 149,
                            columnNumber: 13
                        }, this),
                        totalUnread > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "absolute -top-1 -right-1 bg-red-500 text-white text-xs w-6 h-6 rounded-full flex items-center justify-center",
                            children: totalUnread
                        }, void 0, false, {
                            fileName: "[project]/components/ChatWidget.tsx",
                            lineNumber: 151,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true)
            }, void 0, false, {
                fileName: "[project]/components/ChatWidget.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-24 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden border border-gray-200",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-[#a97456] text-white p-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "font-bold text-lg",
                                            children: "Live Chat Support"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 166,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs opacity-90",
                                            children: "We're here to help!"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 167,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ChatWidget.tsx",
                                    lineNumber: 165,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setShowNewChat(!showNewChat),
                                    className: "w-8 h-8 bg-white/20 rounded-full hover:bg-white/30 flex items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "bi bi-plus-lg"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ChatWidget.tsx",
                                        lineNumber: 173,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/ChatWidget.tsx",
                                    lineNumber: 169,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ChatWidget.tsx",
                            lineNumber: 164,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ChatWidget.tsx",
                        lineNumber: 163,
                        columnNumber: 11
                    }, this),
                    showNewChat && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-4 bg-blue-50 border-b",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "font-semibold text-sm mb-2",
                                children: "New Conversation"
                            }, void 0, false, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 181,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                value: newChatSubject,
                                onChange: (e)=>setNewChatSubject(e.target.value),
                                placeholder: "Subject",
                                className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm mb-2 focus:ring-2 focus:ring-[#a97456] focus:border-transparent"
                            }, void 0, false, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 182,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                value: messageInput,
                                onChange: (e)=>setMessageInput(e.target.value),
                                placeholder: "Your message...",
                                rows: 3,
                                className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm mb-2 focus:ring-2 focus:ring-[#a97456] focus:border-transparent"
                            }, void 0, false, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 189,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: createNewChat,
                                        disabled: sending,
                                        className: "flex-1 bg-[#a97456] text-white py-2 rounded-lg text-sm hover:bg-[#8f6249] disabled:opacity-50",
                                        children: "Start Chat"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ChatWidget.tsx",
                                        lineNumber: 197,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setShowNewChat(false);
                                            setNewChatSubject('');
                                            setMessageInput('');
                                        },
                                        className: "px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50",
                                        children: "Cancel"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ChatWidget.tsx",
                                        lineNumber: 204,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 196,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ChatWidget.tsx",
                        lineNumber: 180,
                        columnNumber: 13
                    }, this),
                    !selectedConv && conversations.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 overflow-y-auto",
                        children: conversations.map((conv)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: ()=>setSelectedConv(conv),
                                className: "p-3 border-b hover:bg-gray-50 cursor-pointer",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-start justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "font-semibold text-sm",
                                                    children: conv.subject
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ChatWidget.tsx",
                                                    lineNumber: 229,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 truncate",
                                                    children: conv.last_message
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ChatWidget.tsx",
                                                    lineNumber: 230,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 228,
                                            columnNumber: 21
                                        }, this),
                                        conv.unread_count > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "bg-red-500 text-white text-xs px-2 py-1 rounded-full",
                                            children: conv.unread_count
                                        }, void 0, false, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 233,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ChatWidget.tsx",
                                    lineNumber: 227,
                                    columnNumber: 19
                                }, this)
                            }, conv.id, false, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 222,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ChatWidget.tsx",
                        lineNumber: 220,
                        columnNumber: 13
                    }, this),
                    selectedConv && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3 border-b bg-gray-50 flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setSelectedConv(null),
                                        className: "text-gray-600 hover:text-gray-800",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: "bi bi-arrow-left"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 252,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/ChatWidget.tsx",
                                        lineNumber: 248,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-semibold text-sm",
                                                children: selectedConv.subject
                                            }, void 0, false, {
                                                fileName: "[project]/components/ChatWidget.tsx",
                                                lineNumber: 255,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-500",
                                                children: selectedConv.status
                                            }, void 0, false, {
                                                fileName: "[project]/components/ChatWidget.tsx",
                                                lineNumber: 256,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/ChatWidget.tsx",
                                        lineNumber: 254,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 247,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50",
                                children: [
                                    messages.map((msg)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `flex ${msg.sender_type === 'customer' ? 'justify-end' : 'justify-start'}`,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `max-w-[80%] ${msg.sender_type === 'customer' ? 'bg-[#a97456] text-white' : 'bg-white border border-gray-200'} rounded-2xl p-3 shadow-sm`,
                                                children: [
                                                    msg.sender_type === 'admin' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs font-semibold mb-1 text-[#a97456]",
                                                        children: msg.sender_name
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ChatWidget.tsx",
                                                        lineNumber: 273,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm whitespace-pre-wrap",
                                                        children: msg.message
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ChatWidget.tsx",
                                                        lineNumber: 275,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: `text-xs mt-1 ${msg.sender_type === 'customer' ? 'text-white/70' : 'text-gray-400'}`,
                                                        children: new Date(msg.created_at).toLocaleTimeString('id-ID', {
                                                            hour: '2-digit',
                                                            minute: '2-digit'
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ChatWidget.tsx",
                                                        lineNumber: 276,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/ChatWidget.tsx",
                                                lineNumber: 267,
                                                columnNumber: 21
                                            }, this)
                                        }, msg.id, false, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 263,
                                            columnNumber: 19
                                        }, this)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        ref: messagesEndRef
                                    }, void 0, false, {
                                        fileName: "[project]/components/ChatWidget.tsx",
                                        lineNumber: 287,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 261,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3 border-t bg-white",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            value: messageInput,
                                            onChange: (e)=>setMessageInput(e.target.value),
                                            onKeyPress: (e)=>e.key === 'Enter' && sendMessage(),
                                            placeholder: "Type a message...",
                                            className: "flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-[#a97456] focus:border-transparent"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 293,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: sendMessage,
                                            disabled: sending || !messageInput.trim(),
                                            className: "px-4 py-2 bg-[#a97456] text-white rounded-lg hover:bg-[#8f6249] disabled:opacity-50 disabled:cursor-not-allowed",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                className: "bi bi-send"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ChatWidget.tsx",
                                                lineNumber: 306,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/ChatWidget.tsx",
                                            lineNumber: 301,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ChatWidget.tsx",
                                    lineNumber: 292,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/ChatWidget.tsx",
                                lineNumber: 291,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true),
                    conversations.length === 0 && !showNewChat && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 flex items-center justify-center p-8 text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                    className: "bi bi-chat-dots text-6xl text-gray-300 mb-4"
                                }, void 0, false, {
                                    fileName: "[project]/components/ChatWidget.tsx",
                                    lineNumber: 317,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-500 mb-4",
                                    children: "No conversations yet"
                                }, void 0, false, {
                                    fileName: "[project]/components/ChatWidget.tsx",
                                    lineNumber: 318,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setShowNewChat(true),
                                    className: "bg-[#a97456] text-white px-6 py-2 rounded-lg hover:bg-[#8f6249]",
                                    children: "Start a Conversation"
                                }, void 0, false, {
                                    fileName: "[project]/components/ChatWidget.tsx",
                                    lineNumber: 319,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ChatWidget.tsx",
                            lineNumber: 316,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ChatWidget.tsx",
                        lineNumber: 315,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ChatWidget.tsx",
                lineNumber: 161,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(ChatWidget, "5QNtRbFEATx830V1ww1l0iDrykc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"]
    ];
});
_c = ChatWidget;
var _c;
__turbopack_context__.k.register(_c, "ChatWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_d1b2a087._.js.map