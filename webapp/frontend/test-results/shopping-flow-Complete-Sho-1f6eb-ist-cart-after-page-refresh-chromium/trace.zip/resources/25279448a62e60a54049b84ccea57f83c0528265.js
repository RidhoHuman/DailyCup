(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CLSThresholds",
    ()=>b,
    "FCPThresholds",
    ()=>y,
    "INPThresholds",
    ()=>B,
    "LCPThresholds",
    ()=>q,
    "TTFBThresholds",
    ()=>H,
    "onCLS",
    ()=>L,
    "onFCP",
    ()=>E,
    "onINP",
    ()=>S,
    "onLCP",
    ()=>x,
    "onTTFB",
    ()=>$
]);
let e = -1;
const t = (t)=>{
    addEventListener("pageshow", (n)=>{
        n.persisted && (e = n.timeStamp, t(n));
    }, !0);
}, n = (e, t, n, i)=>{
    let s, o;
    return (r)=>{
        t.value >= 0 && (r || i) && (o = t.value - (s ?? 0), (o || void 0 === s) && (s = t.value, t.delta = o, t.rating = ((e, t)=>e > t[1] ? "poor" : e > t[0] ? "needs-improvement" : "good")(t.value, n), e(t)));
    };
}, i = (e)=>{
    requestAnimationFrame(()=>requestAnimationFrame(()=>e()));
}, s = ()=>{
    const e = performance.getEntriesByType("navigation")[0];
    if (e && e.responseStart > 0 && e.responseStart < performance.now()) return e;
}, o = ()=>{
    const e = s();
    return e?.activationStart ?? 0;
}, r = (t, n = -1)=>{
    const i = s();
    let r = "navigate";
    e >= 0 ? r = "back-forward-cache" : i && (document.prerendering || o() > 0 ? r = "prerender" : document.wasDiscarded ? r = "restore" : i.type && (r = i.type.replace(/_/g, "-")));
    return {
        name: t,
        value: n,
        rating: "good",
        delta: 0,
        entries: [],
        id: `v5-${Date.now()}-${Math.floor(8999999999999 * Math.random()) + 1e12}`,
        navigationType: r
    };
}, c = new WeakMap;
function a(e, t) {
    return c.get(e) || c.set(e, new t), c.get(e);
}
class d {
    t;
    i = 0;
    o = [];
    h(e) {
        if (e.hadRecentInput) return;
        const t = this.o[0], n = this.o.at(-1);
        this.i && t && n && e.startTime - n.startTime < 1e3 && e.startTime - t.startTime < 5e3 ? (this.i += e.value, this.o.push(e)) : (this.i = e.value, this.o = [
            e
        ]), this.t?.(e);
    }
}
const h = (e, t, n = {})=>{
    try {
        if (PerformanceObserver.supportedEntryTypes.includes(e)) {
            const i = new PerformanceObserver((e)=>{
                Promise.resolve().then(()=>{
                    t(e.getEntries());
                });
            });
            return i.observe({
                type: e,
                buffered: !0,
                ...n
            }), i;
        }
    } catch  {}
}, f = (e)=>{
    let t = !1;
    return ()=>{
        t || (e(), t = !0);
    };
};
let u = -1;
const l = new Set, m = ()=>"hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0, p = (e)=>{
    if ("hidden" === document.visibilityState) {
        if ("visibilitychange" === e.type) for (const e of l)e();
        isFinite(u) || (u = "visibilitychange" === e.type ? e.timeStamp : 0, removeEventListener("prerenderingchange", p, !0));
    }
}, v = ()=>{
    if (u < 0) {
        const e = o(), n = document.prerendering ? void 0 : globalThis.performance.getEntriesByType("visibility-state").filter((t)=>"hidden" === t.name && t.startTime > e)[0]?.startTime;
        u = n ?? m(), addEventListener("visibilitychange", p, !0), addEventListener("prerenderingchange", p, !0), t(()=>{
            setTimeout(()=>{
                u = m();
            });
        });
    }
    return {
        get firstHiddenTime () {
            return u;
        },
        onHidden (e) {
            l.add(e);
        }
    };
}, g = (e)=>{
    document.prerendering ? addEventListener("prerenderingchange", ()=>e(), !0) : e();
}, y = [
    1800,
    3e3
], E = (e, s = {})=>{
    g(()=>{
        const c = v();
        let a, d = r("FCP");
        const f = h("paint", (e)=>{
            for (const t of e)"first-contentful-paint" === t.name && (f.disconnect(), t.startTime < c.firstHiddenTime && (d.value = Math.max(t.startTime - o(), 0), d.entries.push(t), a(!0)));
        });
        f && (a = n(e, d, y, s.reportAllChanges), t((t)=>{
            d = r("FCP"), a = n(e, d, y, s.reportAllChanges), i(()=>{
                d.value = performance.now() - t.timeStamp, a(!0);
            });
        }));
    });
}, b = [
    .1,
    .25
], L = (e, s = {})=>{
    const o = v();
    E(f(()=>{
        let c, f = r("CLS", 0);
        const u = a(s, d), l = (e)=>{
            for (const t of e)u.h(t);
            u.i > f.value && (f.value = u.i, f.entries = u.o, c());
        }, m = h("layout-shift", l);
        m && (c = n(e, f, b, s.reportAllChanges), o.onHidden(()=>{
            l(m.takeRecords()), c(!0);
        }), t(()=>{
            u.i = 0, f = r("CLS", 0), c = n(e, f, b, s.reportAllChanges), i(()=>c());
        }), setTimeout(c));
    }));
};
let P = 0, T = 1 / 0, _ = 0;
const M = (e)=>{
    for (const t of e)t.interactionId && (T = Math.min(T, t.interactionId), _ = Math.max(_, t.interactionId), P = _ ? (_ - T) / 7 + 1 : 0);
};
let w;
const C = ()=>w ? P : performance.interactionCount ?? 0, I = ()=>{
    "interactionCount" in performance || w || (w = h("event", M, {
        type: "event",
        buffered: !0,
        durationThreshold: 0
    }));
};
let F = 0;
class k {
    u = [];
    l = new Map;
    m;
    p;
    v() {
        F = C(), this.u.length = 0, this.l.clear();
    }
    L() {
        const e = Math.min(this.u.length - 1, Math.floor((C() - F) / 50));
        return this.u[e];
    }
    h(e) {
        if (this.m?.(e), !e.interactionId && "first-input" !== e.entryType) return;
        const t = this.u.at(-1);
        let n = this.l.get(e.interactionId);
        if (n || this.u.length < 10 || e.duration > t.P) {
            if (n ? e.duration > n.P ? (n.entries = [
                e
            ], n.P = e.duration) : e.duration === n.P && e.startTime === n.entries[0].startTime && n.entries.push(e) : (n = {
                id: e.interactionId,
                entries: [
                    e
                ],
                P: e.duration
            }, this.l.set(n.id, n), this.u.push(n)), this.u.sort((e, t)=>t.P - e.P), this.u.length > 10) {
                const e = this.u.splice(10);
                for (const t of e)this.l.delete(t.id);
            }
            this.p?.(n);
        }
    }
}
const A = (e)=>{
    const t = globalThis.requestIdleCallback || setTimeout;
    "hidden" === document.visibilityState ? e() : (e = f(e), addEventListener("visibilitychange", e, {
        once: !0,
        capture: !0
    }), t(()=>{
        e(), removeEventListener("visibilitychange", e, {
            capture: !0
        });
    }));
}, B = [
    200,
    500
], S = (e, i = {})=>{
    if (!globalThis.PerformanceEventTiming || !("interactionId" in PerformanceEventTiming.prototype)) return;
    const s = v();
    g(()=>{
        I();
        let o, c = r("INP");
        const d = a(i, k), f = (e)=>{
            A(()=>{
                for (const t of e)d.h(t);
                const t = d.L();
                t && t.P !== c.value && (c.value = t.P, c.entries = t.entries, o());
            });
        }, u = h("event", f, {
            durationThreshold: i.durationThreshold ?? 40
        });
        o = n(e, c, B, i.reportAllChanges), u && (u.observe({
            type: "first-input",
            buffered: !0
        }), s.onHidden(()=>{
            f(u.takeRecords()), o(!0);
        }), t(()=>{
            d.v(), c = r("INP"), o = n(e, c, B, i.reportAllChanges);
        }));
    });
};
class N {
    m;
    h(e) {
        this.m?.(e);
    }
}
const q = [
    2500,
    4e3
], x = (e, s = {})=>{
    g(()=>{
        const c = v();
        let d, u = r("LCP");
        const l = a(s, N), m = (e)=>{
            s.reportAllChanges || (e = e.slice(-1));
            for (const t of e)l.h(t), t.startTime < c.firstHiddenTime && (u.value = Math.max(t.startTime - o(), 0), u.entries = [
                t
            ], d());
        }, p = h("largest-contentful-paint", m);
        if (p) {
            d = n(e, u, q, s.reportAllChanges);
            const o = f(()=>{
                m(p.takeRecords()), p.disconnect(), d(!0);
            }), c = (e)=>{
                e.isTrusted && (A(o), removeEventListener(e.type, c, {
                    capture: !0
                }));
            };
            for (const e of [
                "keydown",
                "click",
                "visibilitychange"
            ])addEventListener(e, c, {
                capture: !0
            });
            t((t)=>{
                u = r("LCP"), d = n(e, u, q, s.reportAllChanges), i(()=>{
                    u.value = performance.now() - t.timeStamp, d(!0);
                });
            });
        }
    });
}, H = [
    800,
    1800
], O = (e)=>{
    document.prerendering ? g(()=>O(e)) : "complete" !== document.readyState ? addEventListener("load", ()=>O(e), !0) : setTimeout(e);
}, $ = (e, i = {})=>{
    let c = r("TTFB"), a = n(e, c, H, i.reportAllChanges);
    O(()=>{
        const d = s();
        d && (c.value = Math.max(d.responseStart - o(), 0), c.entries = [
            d
        ], a(!0), t(()=>{
            c = r("TTFB", 0), a = n(e, c, H, i.reportAllChanges), a(!0);
        }));
    });
};
;
}),
]);

//# sourceMappingURL=node_modules_web-vitals_dist_web-vitals_1a088433.js.map