(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a5d6eb94._.css",
  "static/chunks/node_modules_web-vitals_dist_web-vitals_e70fa19f.js",
  "static/chunks/_d1b2a087._.js",
  "static/chunks/node_modules_3f84eead._.js"
],
    source: "dynamic"
});
