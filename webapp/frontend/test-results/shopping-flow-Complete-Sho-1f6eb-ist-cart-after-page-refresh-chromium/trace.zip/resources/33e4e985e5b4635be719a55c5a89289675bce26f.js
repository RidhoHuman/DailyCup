(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_web-vitals_dist_web-vitals_1a088433.js",
  "static/chunks/node_modules_web-vitals_dist_web-vitals_43f2f73e.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript)");
    });
});
}),
]);