(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e69d2fb4._.js",
  "static/chunks/node_modules_c2e3cb4a._.js"
],
    source: "dynamic"
});
