(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_7b2333cf._.js",
  "static/chunks/node_modules_040b3fa8._.js"
],
    source: "dynamic"
});
